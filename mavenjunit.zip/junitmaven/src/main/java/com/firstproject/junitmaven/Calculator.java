package com.firstproject.junitmaven;

public class Calculator {

	public int add(int i, int j) {
		int a = i+j;
		return a;
	}

	

	
}
