package com.firstproject.junitmaven;

public class SimpleDiv {
	

}
