package com.firstproject.junitmaven;

import static org.junit.Assert.*;

import org.junit.Test;

public class SimpleAdd {
		  @Test
		  public void testSimpleAdd() {
		    Calculator calculator = new Calculator();
		    int sum = calculator.add(2,2);
		    assertEquals(4, sum);
		  }
		}

